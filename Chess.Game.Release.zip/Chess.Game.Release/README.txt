ChessProject 2015 (c)
By Amit Chen and Yehonatan Sayag
This version runs the Graphical interface only
open ChessProject.exe to play. 
Controls: use the mouse to navigate and drag the pieces

NOTE: if your operating system blocks the .exe file: right-click on the program -> properties and on the bottom - choose cancel the block